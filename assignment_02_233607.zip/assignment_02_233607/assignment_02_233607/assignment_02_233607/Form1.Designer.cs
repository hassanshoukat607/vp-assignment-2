﻿namespace assignment_02_233607
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Button1 = new Button();
            lable1 = new Label();
            linkLabel1 = new LinkLabel();
            textBox1 = new TextBox();
            richTextBox1 = new RichTextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            pen = new CheckBox();
            Pencil = new CheckBox();
            button5 = new Button();
            Male = new RadioButton();
            female = new RadioButton();
            button6 = new Button();
            numericUpDown1 = new NumericUpDown();
            button7 = new Button();
            comboBox1 = new ComboBox();
            dateTimePicker1 = new DateTimePicker();
            monthCalendar1 = new MonthCalendar();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Button1
            // 
            Button1.Location = new Point(41, 29);
            Button1.Name = "Button1";
            Button1.Size = new Size(139, 29);
            Button1.TabIndex = 0;
            Button1.Text = "Message Box";
            Button1.UseVisualStyleBackColor = true;
            Button1.Click += Button1_Click;
            // 
            // lable1
            // 
            lable1.AutoSize = true;
            lable1.Location = new Point(50, 81);
            lable1.Name = "lable1";
            lable1.Size = new Size(139, 20);
            lable1.TabIndex = 1;
            lable1.Text = "This is Simple Label";
            lable1.TextAlign = ContentAlignment.TopCenter;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(261, 38);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(116, 20);
            linkLabel1.TabIndex = 2;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "This is Link label";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(195, 78);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(166, 27);
            textBox1.TabIndex = 3;
            textBox1.Text = "This is Text Box";
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(434, 24);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(322, 140);
            richTextBox1.TabIndex = 4;
            richTextBox1.Text = "";
            // 
            // button2
            // 
            button2.Location = new Point(434, 179);
            button2.Name = "button2";
            button2.Size = new Size(83, 29);
            button2.TabIndex = 5;
            button2.Text = "Bold";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(542, 179);
            button3.Name = "button3";
            button3.Size = new Size(83, 29);
            button3.TabIndex = 6;
            button3.Text = "italic";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(645, 179);
            button4.Name = "button4";
            button4.Size = new Size(83, 29);
            button4.TabIndex = 7;
            button4.Text = "Simple";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // pen
            // 
            pen.AutoSize = true;
            pen.Location = new Point(40, 139);
            pen.Name = "pen";
            pen.Size = new Size(54, 24);
            pen.TabIndex = 8;
            pen.Text = "Pen";
            pen.UseVisualStyleBackColor = true;
            // 
            // Pencil
            // 
            Pencil.AutoSize = true;
            Pencil.Location = new Point(40, 179);
            Pencil.Name = "Pencil";
            Pencil.Size = new Size(69, 24);
            Pencil.TabIndex = 9;
            Pencil.Text = "Pencil";
            Pencil.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(115, 161);
            button5.Name = "button5";
            button5.Size = new Size(83, 29);
            button5.TabIndex = 10;
            button5.Text = "Buy";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Male
            // 
            Male.AutoSize = true;
            Male.Location = new Point(229, 120);
            Male.Name = "Male";
            Male.Size = new Size(63, 24);
            Male.TabIndex = 11;
            Male.TabStop = true;
            Male.Text = "Male";
            Male.UseVisualStyleBackColor = true;
            // 
            // female
            // 
            female.AutoSize = true;
            female.Location = new Point(229, 161);
            female.Name = "female";
            female.Size = new Size(78, 24);
            female.TabIndex = 12;
            female.TabStop = true;
            female.Text = "Female";
            female.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(313, 136);
            button6.Name = "button6";
            button6.Size = new Size(83, 29);
            button6.TabIndex = 13;
            button6.Text = "Click";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(30, 231);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(150, 27);
            numericUpDown1.TabIndex = 14;
            // 
            // button7
            // 
            button7.Location = new Point(186, 231);
            button7.Name = "button7";
            button7.Size = new Size(83, 29);
            button7.TabIndex = 15;
            button7.Text = "Quantity";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(303, 236);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 16;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(506, 228);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 17;
            // 
            // monthCalendar1
            // 
            monthCalendar1.Location = new Point(506, 257);
            monthCalendar1.Name = "monthCalendar1";
            monthCalendar1.TabIndex = 18;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(38, 316);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(185, 62);
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(60, 335);
            label1.Name = "label1";
            label1.Size = new Size(138, 20);
            label1.TabIndex = 20;
            label1.Text = "Click to add picture";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(792, 468);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(monthCalendar1);
            Controls.Add(dateTimePicker1);
            Controls.Add(comboBox1);
            Controls.Add(button7);
            Controls.Add(numericUpDown1);
            Controls.Add(button6);
            Controls.Add(female);
            Controls.Add(Male);
            Controls.Add(button5);
            Controls.Add(Pencil);
            Controls.Add(pen);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(richTextBox1);
            Controls.Add(textBox1);
            Controls.Add(linkLabel1);
            Controls.Add(lable1);
            Controls.Add(Button1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Button1;
        private Label lable1;
        private LinkLabel linkLabel1;
        private TextBox textBox1;
        private RichTextBox richTextBox1;
        private Button button2;
        private Button button3;
        private Button button4;
        private CheckBox pen;
        private CheckBox Pencil;
        private Button button5;
        private RadioButton Male;
        private RadioButton female;
        private Button button6;
        private NumericUpDown numericUpDown1;
        private Button button7;
        private ComboBox comboBox1;
        private DateTimePicker dateTimePicker1;
        private MonthCalendar monthCalendar1;
        private PictureBox pictureBox1;
        private Label label1;
    }
}
